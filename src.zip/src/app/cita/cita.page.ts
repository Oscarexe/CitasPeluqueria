import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { Cita } from '../citas';
import { Router } from "@angular/router";
import { FirestoreService } from '../firestore.service';
import {AlertController} from "@ionic/angular";


@Component({
  selector: "app-cita",
  templateUrl: "./cita.page.html",
  styleUrls: ["./cita.page.scss"]
})
  
export class CitaPage implements OnInit {
  //variable que almacena la cita
  document: any = {
    id: "",
    data: {} as Cita
  };
  id = null;
  constructor(private activatedRoute: ActivatedRoute, private firestoreService: FirestoreService, private router: Router,public alertController: AlertController ) {}

//añadir al constructor ActivateRoute, para poder usarlo en ngOnInit, en el que obtenemos el valor de ‘id’ y lo metemos en una variable. 

  ngOnInit() {
    this.id = this.activatedRoute.snapshot.paramMap.get("id");
    this.obtenerCita();
  }

  citaEditando: Cita;
  idCitaSelect: String;

  clicBotonInsertar() {
    this.firestoreService.insertar("citas", this.document.data).then(() => {
      console.log('Jugador creado correctamente!');
      this.citaEditando= {} as Cita;
    }, (error) => {
      console.error(error);
    });
    this.router.navigate(["/home/"]);
  }
    //Mensaje de confirmacion de borrado
    async alertaConfirmacion() {
      const alert = await this.alertController.create({
        cssClass: 'my-custom-class',
        header: 'Citas Peluquería',
        subHeader: 'Confirmación de borrado',
        message: '¿Está seguro que desea eliminar esta cita y todos los datos relacionados con ella?',
        buttons: [
          {
            text: 'OK',
            role: 'submit',
            handler: () => {
              this.clicBotonBorrar();
            }
          }, 
            {
              text: 'Cancel',
              role: 'cancel',
              handler: () => {
                console.log('Cancel clicked');
              }
            }
          ]
      });
  
      await alert.present();
    }

  clicBotonBorrar() {
    this.firestoreService.borrar("citas", this.id).then(() => {
    this.router.navigate(["/home/"]);
    })
  }
  
  clicBotonModificar() {
    this.firestoreService.actualizar("citas", this.id, this.document.data).then(() => {
      // Limpiar datos de pantalla
      //this.citaEditando = {} as Cita;
      this.router.navigate(["/home/"]);
  
    })
  }
  obtenerCita(){
    this.firestoreService.consultarPorId("citas", this.id).subscribe((resultado) => {
      // Preguntar si se hay encontrado un document con ese ID
      if(resultado.payload.data() != null) {
        this.document.id = resultado.payload.id
        this.document.data = resultado.payload.data();
      } else {
        // No se ha encontrado un document con ese ID. Vaciar los datos que hubiera
        this.document.data = {} as Cita;
      } 
    });

  }

}

