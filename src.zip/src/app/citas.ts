export interface Cita {
    nombre: string;
    numeroTlf: number;
    dia:string;
    usuario: String;
}



